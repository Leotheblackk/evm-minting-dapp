const contractAddress = "YOUR_CONTRACT_ADDRESS";
const abi = [
  "function mint(string memory tokenURI) public returns (uint256)",
];

async function mintNFT() {
  if (typeof window.ethereum === 'undefined') {
    alert('MetaMask is not installed');
    return;
  }

  await window.ethereum.request({ method: 'eth_requestAccounts' });
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner();
  const contract = new ethers.Contract(contractAddress, abi, signer);

  const tokenURI = document.getElementById('tokenURI').value;
  try {
    const tx = await contract.mint(tokenURI);
    document.getElementById('status').innerText = `Minting... TX: ${tx.hash}`;
    await tx.wait();
    document.getElementById('status').innerText = `Minted successfully!`;
  } catch (err) {
    document.getElementById('status').innerText = `Error: ${err.message}`;
  }
}
